# Nuclear Strike – Fabric mod for Minecraft 1.21.1

## Build
1. Install JDK 21.
2. Copy the Gradle wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/`) from the official
   Fabric example mod (https://github.com/FabricMC/fabric-example-mod, branch 1.21) into this folder,
   or just run `gradle wrapper` if you have Gradle installed.
3. `./gradlew build`  ->  `build/libs/nuclearstrike-1.0.0.jar` into your `mods` folder (needs Fabric API).
   For testing: `./gradlew runClient`.

## Play
* Get the **Nuclear Control** from the creative tab (Tools) – or find it in dungeon / temple / mansion chests.
* Right click -> terminal opens. Enter target X / Z, the code **731945**, press **ARM**,
  then the big red button unlocks. Press it.
* Cutscene (~12 s): submarine surfaces, missile rises out of the hatch, ignites and leaves the atmosphere.
  Afterwards you are back at your player.
* Everyone gets the alarm, **Air Raid Sirens** (craft: iron/redstone/note block) howl for 3 minutes,
  then the warhead re-enters and detonates at the target (crater, mushroom cloud, shockwave).

Change the code in `NuclearStrike.LAUNCH_CODE`, the blast size in `NukeManager.BLAST_RADIUS`.
Regenerate models/textures/siren with `python3 tools/generate_assets.py` (needs numpy, Pillow, ffmpeg).
