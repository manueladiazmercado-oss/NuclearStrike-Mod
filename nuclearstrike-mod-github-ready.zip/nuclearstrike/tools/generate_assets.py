#!/usr/bin/env python3
"""Generates all models, textures and the siren sound for the NuclearStrike mod.
Run from the project root:  python3 tools/generate_assets.py
Needs: numpy, Pillow, ffmpeg (for the .ogg)."""
import json, os, subprocess, tempfile, wave
import numpy as np
from PIL import Image

MOD = "nuclearstrike"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", MOD)
for d in ("models/item", "models/block", "textures/item", "textures/block", "blockstates", "lang", "sounds"):
    os.makedirs(os.path.join(ROOT, d), exist_ok=True)

def w(path, obj):
    with open(os.path.join(ROOT, path), "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

# ---------------------------------------------------------------- palette helper
class Palette:
    """16x16 texture where every pixel is one flat colour swatch."""
    def __init__(self, colors):
        self.names = list(colors)
        self.img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
        for i, n in enumerate(self.names):
            self.img.putpixel((i % 16, i // 16), colors[n] + (255,))
    def uv(self, n):
        i = self.names.index(n)
        x, y = i % 16, i // 16
        return [x + 0.25, y + 0.25, x + 0.75, y + 0.75]

def box(frm, to, uv, rot=None, faces=None):
    e = {"from": list(frm), "to": list(to), "faces": {}}
    for f in ("north", "south", "east", "west", "up", "down"):
        e["faces"][f] = {"uv": uv, "texture": "#t"}
    if faces:
        for f, u in faces.items():
            e["faces"][f] = {"uv": u, "texture": "#t"}
    if rot:
        e["rotation"] = {"angle": rot, "axis": "y", "origin": [8, frm[1], 8]}
    return e

def cyl(y1, y2, wd, uv, cx=8, cz=8):
    """octagon-ish 'cylinder' = box + same box turned 45 degrees"""
    h = wd / 2
    a = box([cx - h, y1, cz - h], [cx + h, y2, cz + h], uv)
    b = box([cx - h, y1, cz - h], [cx + h, y2, cz + h], uv, rot=45)
    b["rotation"]["origin"] = [cx, y1, cz]
    return [a, b]

# ---------------------------------------------------------------- MISSILE
P = Palette({"white": (226, 228, 232), "grey": (150, 155, 162), "dark": (40, 42, 48),
             "red": (190, 30, 30), "black": (18, 18, 20), "orange": (255, 140, 30), "olive": (84, 92, 70)})
el = []
el += cyl(0.0, 1.2, 2.4, P.uv("black"))                       # nozzle
el += cyl(1.2, 11.0, 3.0, P.uv("white"))                      # body
el += cyl(3.0, 4.0, 3.2, P.uv("dark"))                        # band
el += cyl(6.0, 7.2, 3.2, P.uv("red"))                         # red band
el += cyl(8.8, 9.6, 3.2, P.uv("dark"))
el += cyl(11.0, 12.4, 2.6, P.uv("grey"))                      # ogive
el += cyl(12.4, 13.6, 1.8, P.uv("grey"))
el += cyl(13.6, 14.6, 1.0, P.uv("dark"))
el += cyl(14.6, 15.2, 0.4, P.uv("black"))
for sx in (-1, 1):                                            # fins
    el.append(box([8 + (1.5 if sx > 0 else -3.4), 1.2, 7.8], [8 + (3.4 if sx > 0 else -1.5), 4.4, 8.2], P.uv("dark")))
    el.append(box([7.8, 1.2, 8 + (1.5 if sx > 0 else -3.4)], [8.2, 4.4, 8 + (3.4 if sx > 0 else -1.5)], P.uv("dark")))
w("models/item/missile_display.json", {"textures": {"t": f"{MOD}:item/missile", "particle": f"{MOD}:item/missile"}, "elements": el})
P.img.save(os.path.join(ROOT, "textures/item/missile.png"))

# ---------------------------------------------------------------- SUBMARINE   (nose = +Z)
S = Palette({"hull": (44, 52, 64), "hull2": (58, 68, 82), "black": (14, 16, 20), "rust": (92, 54, 40),
             "light": (210, 60, 40), "glass": (90, 140, 160)})
el = []
el.append(box([6, 0, 1.5], [10, 4, 14.5], S.uv("hull")))                    # main hull
el.append(box([6.8, -0.5, 2], [9.2, 4.5, 14], S.uv("hull2"), rot=45))      # rounding
el.append(box([6.7, 4, 2], [9.3, 4.6, 14], S.uv("hull2")))                  # deck
el.append(box([6.6, 0.4, 14.5], [9.4, 3.6, 15.3], S.uv("hull")))            # bow
el.append(box([7.2, 0.9, 15.3], [8.8, 3.1, 16], S.uv("hull2")))
el.append(box([6.6, 0.4, 0.8], [9.4, 3.6, 1.5], S.uv("hull")))              # stern
el.append(box([7.2, 0.9, 0.2], [8.8, 3.1, 0.8], S.uv("hull2")))
el.append(box([4.6, 1.7, 0.6], [11.4, 2.3, 1.8], S.uv("hull2")))            # tail planes
el.append(box([7.7, -0.3, 0.6], [8.3, 4.3, 1.8], S.uv("hull2")))
el.append(box([4.9, 1.6, 11.5], [11.1, 2.2, 12.5], S.uv("hull2")))          # bow planes
el.append(box([6.4, 4.0, 6.0], [9.6, 4.7, 10.0], S.uv("hull2")))            # sail base
el.append(box([7.0, 4.6, 6.2], [9.0, 7.0, 9.8], S.uv("hull")))              # sail
el.append(box([7.2, 6.0, 9.8], [8.8, 6.6, 9.85], S.uv("glass")))
el.append(box([7.85, 7.0, 7.6], [8.15, 8.6, 7.9], S.uv("black")))           # periscope
el.append(box([7.85, 8.4, 7.6], [8.15, 8.6, 8.4], S.uv("black")))
el.append(box([7.9, 7.0, 8.4], [8.1, 8.2, 8.55], S.uv("black")))
el.append(box([7.8, 4.6, 6.9], [8.2, 4.9, 7.1], S.uv("light")))
# missile hatch (matches MissileEntity start position, 3.5px from stern side)
el.append(box([6.9, 4.62, 2.3], [9.1, 4.66, 4.9], S.uv("black")))
w("models/item/submarine_display.json", {"textures": {"t": f"{MOD}:item/submarine", "particle": f"{MOD}:item/submarine"}, "elements": el})
S.img.save(os.path.join(ROOT, "textures/item/submarine.png"))

# ---------------------------------------------------------------- SIREN BLOCK
B = Palette({"metal": (122, 128, 136), "dark": (52, 56, 64), "red": (180, 36, 32), "black": (20, 22, 26), "light": (170, 176, 184)})
el = []
el.append(box([3, 0, 3], [13, 2, 13], B.uv("dark")))
el.append(box([6.5, 2, 6.5], [9.5, 9, 9.5], B.uv("metal")))
el.append(box([4.5, 9, 4.5], [11.5, 12.5, 11.5], B.uv("dark")))
el.append(box([4.3, 10.2, 4.3], [11.7, 11.2, 11.7], B.uv("red")))
el.append(box([1.5, 12.5, 6], [14.5, 15.5, 10], B.uv("metal")))             # horn arm
el.append(box([-0.5, 11.8, 5], [2, 16.2, 11], B.uv("light")))              # bell W
el.append(box([14, 11.8, 5], [16.5, 16.2, 11], B.uv("light")))             # bell E
el.append(box([-0.6, 12.3, 5.6], [0.1, 15.7, 10.4], B.uv("black")))
el.append(box([15.9, 12.3, 5.6], [16.6, 15.7, 10.4], B.uv("black")))
el.append(box([7.2, 15.5, 7.2], [8.8, 16.5, 8.8], B.uv("red")))
w("models/block/air_raid_siren.json", {"parent": "minecraft:block/block",
    "textures": {"t": f"{MOD}:block/air_raid_siren", "particle": f"{MOD}:block/air_raid_siren"}, "elements": el})
w("models/item/air_raid_siren.json", {"parent": f"{MOD}:block/air_raid_siren"})
w("blockstates/air_raid_siren.json", {"variants": {"": {"model": f"{MOD}:block/air_raid_siren"}}})
B.img.save(os.path.join(ROOT, "textures/block/air_raid_siren.png"))

# ---------------------------------------------------------------- NUCLEAR CONTROL (3D phone-like device, 64x64 tex)
T = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
px = T.load()
def rect(x1, y1, x2, y2, c):
    for x in range(x1, x2):
        for y in range(y1, y2):
            px[x, y] = c + (255,)
# swatches in the lower right corner
SW = {"body": (36, 40, 46), "black": (12, 13, 16), "red": (190, 24, 24), "silver": (150, 156, 164), "yellow": (230, 190, 30), "green": (40, 210, 90)}
swuv = {}
for i, (n, c) in enumerate(SW.items()):
    rect(56 + i % 4 * 2, 56 + i // 4 * 2, 58 + i % 4 * 2, 58 + i // 4 * 2, c)
    swuv[n] = [(56 + i % 4 * 2 + .5) / 4, (56 + i // 4 * 2 + .5) / 4, (57 + i % 4 * 2 + .5) / 4, (57 + i // 4 * 2 + .5) / 4]
# front face art: occupies texture px x 16..48, y 0..60 (8x15 model px -> 32x60 tex px, 4 tex px per model px)
X0, Y0 = 16, 0
rect(X0, Y0, X0 + 32, Y0 + 60, SW["body"])
rect(X0 + 2, Y0 + 2, X0 + 30, Y0 + 58, (22, 25, 30))                      # bezel
rect(X0 + 4, Y0 + 4, X0 + 28, Y0 + 22, (8, 40, 24))                       # screen
for r in range(6, 20, 3):                                                  # fake text lines
    rect(X0 + 6, Y0 + r, X0 + 6 + (14 if r % 2 else 10), Y0 + r + 1, (40, 210, 90))
rect(X0 + 22, Y0 + 6, X0 + 26, Y0 + 9, (210, 40, 40))                     # warning light
for row in range(4):                                                       # keypad
    for col in range(3):
        rect(X0 + 5 + col * 8, Y0 + 38 + row * 5 - 0, X0 + 10 + col * 8, Y0 + 41 + row * 5, (90, 96, 104))
rect(X0 + 4, Y0 + 24, X0 + 28, Y0 + 26, (230, 190, 30))                   # hazard stripe
for k in range(0, 24, 4):
    rect(X0 + 4 + k, Y0 + 24, X0 + 6 + k, Y0 + 26, (20, 20, 20))
T.save(os.path.join(ROOT, "textures/item/nuclear_control.png"))
front = [16 / 4, 0, 48 / 4, 60 / 4]
el = []
el.append(box([4, 0, 7], [12, 15, 9], swuv["body"], faces={"south": [4, 0, 12, 15], "north": [4, 0, 12, 15]}))
el[-1]["faces"]["south"]["uv"] = [front[0], front[1], front[2], front[3]]
el[-1]["faces"]["north"]["uv"] = [front[2], front[1], front[0], front[3]]
el.append(box([9.6, 15, 7.6], [10.6, 19, 8.4], swuv["black"]))                       # antenna
el.append(box([9.4, 18.2, 7.4], [10.8, 19.2, 8.6], swuv["red"]))
el.append(box([6, 6.5, 9], [10, 9.5, 9.7], swuv["silver"]))                            # button guard
el.append(box([6.6, 7, 9.7], [9.4, 9, 10.6], swuv["red"]))                             # BIG RED BUTTON
el.append(box([4, 6.2, 9], [6, 9.8, 9.3], swuv["yellow"]))
el.append(box([10, 6.2, 9], [12, 9.8, 9.3], swuv["yellow"]))
el.append(box([5, 13.2, 6.6], [7, 14.2, 7], swuv["green"]))                          # status led back
disp = {
    "gui": {"rotation": [20, -35, 0], "translation": [0, -1, 0], "scale": [0.85, 0.85, 0.85]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.9, 0.9, 0.9]},
    "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
}
w("models/item/nuclear_control.json", {"textures": {"t": f"{MOD}:item/nuclear_control", "particle": f"{MOD}:item/nuclear_control"},
                                       "elements": el, "display": disp})

# ---------------------------------------------------------------- LANG
w("lang/en_us.json", {
    "item.nuclearstrike.nuclear_control": "Nuclear Control",
    "item.nuclearstrike.missile_display": "Missile (display)",
    "item.nuclearstrike.submarine_display": "Submarine (display)",
    "block.nuclearstrike.air_raid_siren": "Air Raid Siren",
    "entity.nuclearstrike.missile": "SLBM",
    "entity.nuclearstrike.submarine": "Ballistic Submarine",
    "entity.nuclearstrike.camera": "Camera",
    "subtitles.nuclearstrike.air_raid_siren": "Air raid siren wails",
    "tooltip.nuclearstrike.nuclear_control": "Needs the launch code. Handle with care.",
    "gui.nuclearstrike.title": "STRATEGIC LAUNCH TERMINAL",
})
w("lang/de_de.json", {
    "item.nuclearstrike.nuclear_control": "Nuklearsteuerung",
    "item.nuclearstrike.missile_display": "Rakete (Anzeige)",
    "item.nuclearstrike.submarine_display": "U-Boot (Anzeige)",
    "block.nuclearstrike.air_raid_siren": "Luftschutzsirene",
    "entity.nuclearstrike.missile": "Atomrakete",
    "entity.nuclearstrike.submarine": "Raketen-U-Boot",
    "entity.nuclearstrike.camera": "Kamera",
    "subtitles.nuclearstrike.air_raid_siren": "Luftschutzsirene heult",
    "tooltip.nuclearstrike.nuclear_control": "Benötigt den Startcode. Vorsicht!",
    "gui.nuclearstrike.title": "STRATEGISCHES STARTTERMINAL",
})
w("sounds.json", {"air_raid_siren": {"sounds": [{"name": f"{MOD}:air_raid_siren", "stream": True}],
                                       "subtitle": f"subtitles.{MOD}.air_raid_siren"}})

# ---------------------------------------------------------------- SIREN SOUND (synthesised, 20 s seamless loop)
SR = 44100
DUR = 20.0
N = int(SR * DUR)
t = np.arange(N) / SR
cycle = 10.0                                     # one wail up+down = 10 s
ph = (t % cycle) / cycle
sweep = 0.5 - 0.5 * np.cos(2 * np.pi * ph)       # 0..1..0 smooth
# slight inertia like a real rotor: smooth the sweep
freq = 330 + 215 * sweep
phase = 2 * np.pi * np.cumsum(freq) / SR
sig = np.zeros(N)
for k, a in ((1, 1.0), (2, 0.55), (3, 0.38), (4, 0.2), (5, 0.12), (6, 0.07)):
    sig += a * np.sin(k * phase + 0.3 * k)
sig *= 0.75 + 0.25 * sweep                        # louder at the top of the wail
sig *= 1.0 + 0.04 * np.sin(2 * np.pi * 7.3 * t)   # rotor flutter
rumble = 0.08 * np.sin(2 * np.pi * 48 * t) * (0.6 + 0.4 * sweep)
rng = np.random.default_rng(7)
noise = rng.normal(0, 1, N)
k = np.ones(40) / 40
noise = np.convolve(noise, k, mode="same") * 0.35
sig = sig / np.max(np.abs(sig)) + rumble + 0.02 * noise
dry = sig.copy()
for delay, g in ((0.11, 0.38), (0.23, 0.26), (0.41, 0.17), (0.67, 0.10)):   # circular echo -> loops cleanly
    sig += g * np.roll(dry, int(delay * SR))
sig = np.tanh(sig * 0.9)
sig /= np.max(np.abs(sig))
sig *= 0.9
pcm = (sig * 32767).astype("<i2")
tmp = os.path.join(tempfile.gettempdir(), "siren.wav")
with wave.open(tmp, "wb") as wf:
    wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(pcm.tobytes())
out = os.path.join(ROOT, "sounds", "air_raid_siren.ogg")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "5", out], check=True)
print("assets generated")
