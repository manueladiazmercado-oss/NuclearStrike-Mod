package com.nuclearstrike;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

public final class ModItems {
    public static final Item NUCLEAR_CONTROL = register("nuclear_control",
            new NuclearControlItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
    public static final Item AIR_RAID_SIREN = register("air_raid_siren",
            new BlockItem(ModBlocks.AIR_RAID_SIREN, new Item.Settings()));

    // only used so the entity renderers can draw their 3D models (not obtainable in survival)
    public static final Item MISSILE_DISPLAY = register("missile_display", new Item(new Item.Settings()));
    public static final Item SUBMARINE_DISPLAY = register("submarine_display", new Item(new Item.Settings()));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, NuclearStrike.id(name), item);
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(NUCLEAR_CONTROL);
            entries.add(AIR_RAID_SIREN);
        });
    }

    private ModItems() {}
}
