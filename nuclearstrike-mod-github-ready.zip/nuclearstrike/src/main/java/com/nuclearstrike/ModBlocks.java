package com.nuclearstrike;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModBlocks {
    public static final Block AIR_RAID_SIREN = Registry.register(Registries.BLOCK, NuclearStrike.id("air_raid_siren"),
            new SirenBlock(AbstractBlock.Settings.create()
                    .mapColor(MapColor.IRON_GRAY)
                    .strength(3.0f, 6.0f)
                    .sounds(BlockSoundGroup.METAL)
                    .nonOpaque()));

    public static final BlockEntityType<SirenBlockEntity> SIREN_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE,
            NuclearStrike.id("air_raid_siren"),
            FabricBlockEntityTypeBuilder.create(SirenBlockEntity::new, AIR_RAID_SIREN).build());

    public static void init() {}

    private ModBlocks() {}
}
