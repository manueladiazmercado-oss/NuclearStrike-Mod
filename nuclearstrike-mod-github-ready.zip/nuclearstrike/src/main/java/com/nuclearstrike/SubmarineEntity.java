package com.nuclearstrike;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

public class SubmarineEntity extends SceneEntity {
    public SubmarineEntity(EntityType<?> type, World world) {
        super(type, world);
    }
}
