package com.nuclearstrike;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.world.World;

public class MissileEntity extends SceneEntity {
    private static final TrackedData<Boolean> FLIPPED =
            DataTracker.registerData(MissileEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public MissileEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(FLIPPED, false);
    }

    /** true = warhead pointing down (re-entry). */
    public boolean isFlipped() {
        return this.dataTracker.get(FLIPPED);
    }

    public void setFlipped(boolean flipped) {
        this.dataTracker.set(FLIPPED, flipped);
    }
}
