package com.nuclearstrike;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
    public static final EntityType<MissileEntity> MISSILE = register("missile",
            EntityType.Builder.<MissileEntity>create(MissileEntity::new, SpawnGroup.MISC)
                    .dimensions(1.4f, 6.0f).maxTrackingRange(32).trackingTickInterval(1).disableSaving().disableSummon());
    public static final EntityType<SubmarineEntity> SUBMARINE = register("submarine",
            EntityType.Builder.<SubmarineEntity>create(SubmarineEntity::new, SpawnGroup.MISC)
                    .dimensions(5.0f, 6.0f).maxTrackingRange(32).trackingTickInterval(1).disableSaving().disableSummon());
    public static final EntityType<CameraEntity> CAMERA = register("camera",
            EntityType.Builder.<CameraEntity>create(CameraEntity::new, SpawnGroup.MISC)
                    .dimensions(0.25f, 0.25f).maxTrackingRange(32).trackingTickInterval(1).disableSaving().disableSummon());

    private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
        return Registry.register(Registries.ENTITY_TYPE, NuclearStrike.id(name), builder.build(name));
    }

    public static void init() {}

    private ModEntities() {}
}
