package com.nuclearstrike;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    /** Length of sounds/air_raid_siren.ogg in ticks (20 s). */
    public static final int SIREN_LOOP_TICKS = 400;
    public static final SoundEvent AIR_RAID_SIREN = register("air_raid_siren");

    private static SoundEvent register(String name) {
        Identifier id = NuclearStrike.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void init() {}

    private ModSounds() {}
}
