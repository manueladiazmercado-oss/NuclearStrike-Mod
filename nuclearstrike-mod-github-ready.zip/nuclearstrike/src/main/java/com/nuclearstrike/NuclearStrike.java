package com.nuclearstrike;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class NuclearStrike implements ModInitializer {
    public static final String MOD_ID = "nuclearstrike";

    /** The launch code that has to be typed into the Nuclear Control. Change it here if you like. */
    public static final String LAUNCH_CODE = "731945";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
        Payloads.register();
        LootHooks.init();
        NukeManager.init();
    }
}
