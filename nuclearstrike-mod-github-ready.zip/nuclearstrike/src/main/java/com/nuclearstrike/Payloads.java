package com.nuclearstrike;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public final class Payloads {
    /** server -> client: open the terminal GUI */
    public record OpenDevice() implements CustomPayload {
        public static final CustomPayload.Id<OpenDevice> ID = new CustomPayload.Id<>(NuclearStrike.id("open_device"));
        public static final PacketCodec<RegistryByteBuf, OpenDevice> CODEC = PacketCodec.unit(new OpenDevice());

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** client -> server: launch request */
    public record LaunchRequest(String code, int x, int z) implements CustomPayload {
        public static final CustomPayload.Id<LaunchRequest> ID = new CustomPayload.Id<>(NuclearStrike.id("launch_request"));
        public static final PacketCodec<RegistryByteBuf, LaunchRequest> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, LaunchRequest::code,
                PacketCodecs.INTEGER, LaunchRequest::x,
                PacketCodecs.INTEGER, LaunchRequest::z,
                LaunchRequest::new);

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** server -> client: start / stop the cutscene camera */
    public record CutsceneControl(boolean start, int cameraId, int totalTicks) implements CustomPayload {
        public static final CustomPayload.Id<CutsceneControl> ID = new CustomPayload.Id<>(NuclearStrike.id("cutscene"));
        public static final PacketCodec<RegistryByteBuf, CutsceneControl> CODEC = PacketCodec.tuple(
                PacketCodecs.BOOL, CutsceneControl::start,
                PacketCodecs.INTEGER, CutsceneControl::cameraId,
                PacketCodecs.INTEGER, CutsceneControl::totalTicks,
                CutsceneControl::new);

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static void register() {
        PayloadTypeRegistry.playS2C().register(OpenDevice.ID, OpenDevice.CODEC);
        PayloadTypeRegistry.playS2C().register(CutsceneControl.ID, CutsceneControl.CODEC);
        PayloadTypeRegistry.playC2S().register(LaunchRequest.ID, LaunchRequest.CODEC);
    }

    private Payloads() {}
}
