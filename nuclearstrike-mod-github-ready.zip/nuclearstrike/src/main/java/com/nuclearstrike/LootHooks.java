package com.nuclearstrike;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;

import java.util.Map;

/** Makes the Nuclear Control show up in dungeon / structure chests. */
public final class LootHooks {
    private static final Map<String, Float> CHANCES = Map.ofEntries(
            Map.entry("chests/simple_dungeon", 0.10f),
            Map.entry("chests/abandoned_mineshaft", 0.08f),
            Map.entry("chests/desert_pyramid", 0.10f),
            Map.entry("chests/jungle_temple", 0.10f),
            Map.entry("chests/stronghold_corridor", 0.12f),
            Map.entry("chests/stronghold_library", 0.12f),
            Map.entry("chests/buried_treasure", 0.20f),
            Map.entry("chests/end_city_treasure", 0.25f),
            Map.entry("chests/woodland_mansion", 0.25f),
            Map.entry("chests/ancient_city", 0.25f),
            Map.entry("chests/bastion_treasure", 0.25f),
            Map.entry("chests/shipwreck_treasure", 0.10f));

    public static void init() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (!source.isBuiltin()) return;
            if (!key.getValue().getNamespace().equals("minecraft")) return;
            Float chance = CHANCES.get(key.getValue().getPath());
            if (chance == null) return;
            tableBuilder.pool(LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .conditionally(RandomChanceLootCondition.builder(chance))
                    .with(ItemEntry.builder(ModItems.NUCLEAR_CONTROL)));
        });
    }

    private LootHooks() {}
}
