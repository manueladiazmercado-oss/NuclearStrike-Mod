package com.nuclearstrike;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class SirenBlockEntity extends BlockEntity {
    public SirenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.SIREN_BE, pos, state);
    }

    public static void tick(World world, BlockPos pos, BlockState state, SirenBlockEntity be) {
        if (!(world instanceof ServerWorld sw)) return;
        int age = NukeManager.alarmAge(sw);
        if (age < 0 || age % ModSounds.SIREN_LOOP_TICKS != 0) return;
        // volume > 1 makes the sound audible from much further away (~16 blocks per 1.0)
        world.playSound(null, pos, ModSounds.AIR_RAID_SIREN, SoundCategory.RECORDS, 10.0f, 1.0f);
    }
}
