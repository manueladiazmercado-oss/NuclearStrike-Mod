package com.nuclearstrike;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Everything server side: launch validation, the cinematic (submarine, missile, camera),
 * the 3 minute flight with sirens, the re-entry and the detonation.
 */
public final class NukeManager {
    public static final int FLIGHT_TICKS = 20 * 60 * 3;        // 3 minutes
    public static final int CUTSCENE_TICKS = 250;
    public static final int BLAST_RADIUS = 42;                  // crater radius in blocks
    private static final int OUTER_RADIUS = (int) (BLAST_RADIUS * 2.4);
    private static final int REENTRY_TICKS = 220;
    private static final int FORCELOAD_TICKS = 700;

    // cutscene timeline (ticks)
    private static final int T_BUBBLES = 40;
    private static final int T_LIFT = 80;
    private static final int T_IGNITE = 135;

    private static final int BLOCK_FLAGS = Block.NOTIFY_LISTENERS | Block.SKIP_DROPS;

    private static final List<Strike> STRIKES = new ArrayList<>();
    private static final List<Cutscene> CUTSCENES = new ArrayList<>();
    private static final List<Blast> BLASTS = new ArrayList<>();
    private static final Random RNG = new Random();

    private static final class Strike {
        final ServerWorld world;
        final int bx, bz;
        int ticksLeft = FLIGHT_TICKS;
        MissileEntity missile;
        boolean forced;
        int groundY;

        Strike(ServerWorld world, int bx, int bz) {
            this.world = world;
            this.bx = bx;
            this.bz = bz;
        }
    }

    private static final class Cutscene {
        final ServerPlayerEntity player;
        final ServerWorld world;
        SubmarineEntity sub;
        MissileEntity missile;
        CameraEntity cam;
        int t;
        float heading;
        double surface, subX, subY, subZ, angle0;
        double holdX, holdZ, ignX, ignY, ignZ, lastMy;

        Cutscene(ServerPlayerEntity player, ServerWorld world) {
            this.player = player;
            this.world = world;
        }
    }

    private static final class Blast {
        final Strike strike;
        final ServerWorld w;
        final int cx, cz, groundY;
        final List<int[]> cols = new ArrayList<>();
        int idx, age;

        Blast(Strike s, int groundY) {
            this.strike = s;
            this.w = s.world;
            this.cx = s.bx;
            this.cz = s.bz;
            this.groundY = groundY;
            for (int dx = -OUTER_RADIUS; dx <= OUTER_RADIUS; dx++) {
                for (int dz = -OUTER_RADIUS; dz <= OUTER_RADIUS; dz++) {
                    int d2 = dx * dx + dz * dz;
                    if (d2 <= OUTER_RADIUS * OUTER_RADIUS) cols.add(new int[]{dx, dz, d2});
                }
            }
            cols.sort(Comparator.comparingInt(a -> a[2]));
        }
    }

    // ------------------------------------------------------------------ setup

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(NukeManager::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            STRIKES.clear();
            CUTSCENES.clear();
            BLASTS.clear();
        });
        ServerPlayNetworking.registerGlobalReceiver(Payloads.LaunchRequest.ID,
                (payload, context) -> handleLaunch(context.player(), payload));
    }

    /** Ticks since the first still-active strike in this world was launched, or -1 if there is no alarm. */
    public static int alarmAge(ServerWorld world) {
        int age = -1;
        for (Strike s : STRIKES) {
            if (s.world == world) age = Math.max(age, FLIGHT_TICKS - s.ticksLeft);
        }
        return age;
    }

    private static void handleLaunch(ServerPlayerEntity p, Payloads.LaunchRequest r) {
        boolean holding = p.getMainHandStack().isOf(ModItems.NUCLEAR_CONTROL)
                || p.getOffHandStack().isOf(ModItems.NUCLEAR_CONTROL);
        if (!holding) return;
        if (!NuclearStrike.LAUNCH_CODE.equals(r.code())) {
            p.sendMessage(Text.literal("ACCESS DENIED").formatted(Formatting.RED), true);
            return;
        }
        for (Cutscene c : CUTSCENES) if (c.player == p) return;
        launch(p, r.x(), r.z());
    }

    private static void launch(ServerPlayerEntity p, int x, int z) {
        ServerWorld world = p.getServerWorld();
        STRIKES.add(new Strike(world, x, z));

        MinecraftServer server = world.getServer();
        Text head = Text.literal("\u2622 NUCLEAR LAUNCH DETECTED").formatted(Formatting.DARK_RED, Formatting.BOLD);
        Text sub = Text.literal("Impact at X " + x + "  Z " + z + " in 3:00").formatted(Formatting.RED);
        for (ServerPlayerEntity o : server.getPlayerManager().getPlayerList()) {
            o.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 90, 20));
            o.networkHandler.sendPacket(new SubtitleS2CPacket(sub));
            o.networkHandler.sendPacket(new TitleS2CPacket(head));
            o.sendMessage(head.copy().append(Text.literal("  ").append(sub)), false);
        }
        startCutscene(p);
    }

    // ------------------------------------------------------------------ main tick

    private static void tick(MinecraftServer server) {
        if (STRIKES.isEmpty() && CUTSCENES.isEmpty() && BLASTS.isEmpty()) return;
        CUTSCENES.removeIf(NukeManager::tickCutscene);
        STRIKES.removeIf(NukeManager::tickStrike);
        BLASTS.removeIf(NukeManager::tickBlast);
    }

    // ------------------------------------------------------------------ helpers

    private static SoundEvent snd(String path) {
        return Registries.SOUND_EVENT.get(Identifier.of("minecraft", path));
    }

    private static void sound(ServerWorld w, double x, double y, double z, String path, float vol, float pitch) {
        SoundEvent e = snd(path);
        if (e != null) w.playSound(null, x, y, z, e, SoundCategory.MASTER, vol, pitch);
    }

    private static void fx(ServerWorld w, ParticleEffect type, double x, double y, double z,
                           int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayerEntity p : w.getPlayers()) {
            w.spawnParticles(p, type, true, x, y, z, count, dx, dy, dz, speed);
        }
    }

    private static void fxP(Cutscene c, ParticleEffect type, double x, double y, double z,
                            int count, double dx, double dy, double dz, double speed) {
        c.world.spawnParticles(c.player, type, true, x, y, z, count, dx, dy, dz, speed);
    }

    private static Vec3d forward(Cutscene c) {
        double r = Math.toRadians(c.heading);
        return new Vec3d(-Math.sin(r), 0, Math.cos(r));
    }

    /** position of the missile hatch on the submarine's deck */
    private static Vec3d hatch(Cutscene c) {
        Vec3d f = forward(c);
        return new Vec3d(c.subX - f.x * 5.5, c.surface, c.subZ - f.z * 5.5);
    }

    private static Vec3d orbit(Cutscene c, int t) {
        double a = c.angle0 + t * 0.0105;
        double r = 40 - t * 0.07;
        return new Vec3d(c.subX + Math.cos(a) * r, c.surface + 6 + t * 0.02, c.subZ + Math.sin(a) * r);
    }

    // ------------------------------------------------------------------ cutscene

    private static boolean isOpenWater(ServerWorld w, int x, int z) {
        int[][] offs = {{0, 0}, {12, 0}, {-12, 0}, {0, 12}, {0, -12}};
        for (int[] o : offs) {
            int bx = x + o[0], bz = z + o[1];
            if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return false;
            int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, bx, bz);
            if (!w.getBlockState(new BlockPos(bx, top - 1, bz)).isOf(Blocks.WATER)) return false;
            if (top - w.getTopY(Heightmap.Type.OCEAN_FLOOR, bx, bz) < 7) return false;
        }
        return true;
    }

    /** returns (x, waterSurfaceY, z); falls back to a spot in the sky when there is no ocean nearby */
    private static Vec3d findLaunchSite(ServerWorld w, ServerPlayerEntity p) {
        int view = w.getServer().getPlayerManager().getViewDistance();
        int maxR = Math.min(150, Math.max(2, view - 2) * 16);
        double yawRad = Math.toRadians(p.getYaw());
        double base = Math.atan2(Math.cos(yawRad), -Math.sin(yawRad));
        for (int r = 36; r <= maxR; r += 12) {
            for (int k = 0; k < 16; k++) {
                double a = base + ((k % 2 == 0) ? 1 : -1) * Math.ceil(k / 2.0) * (Math.PI * 2 / 16);
                int x = (int) (p.getX() + Math.cos(a) * r);
                int z = (int) (p.getZ() + Math.sin(a) * r);
                if (isOpenWater(w, x, z)) {
                    int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
                    return new Vec3d(x + 0.5, top - 0.12, z + 0.5);
                }
            }
        }
        p.sendMessage(Text.literal("No ocean nearby - the submarine launches from the sky.").formatted(Formatting.GRAY), false);
        double x = p.getX() - Math.sin(yawRad) * 45;
        double z = p.getZ() + Math.cos(yawRad) * 45;
        int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, (int) x, (int) z);
        return new Vec3d(x, top + 14, z);
    }

    private static void startCutscene(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d site = findLaunchSite(w, p);
        Cutscene c = new Cutscene(p, w);
        c.heading = RNG.nextFloat() * 360f;
        c.surface = site.y;
        c.subX = site.x;
        c.subZ = site.z;
        c.subY = site.y - 3.0;
        // keep the camera's yaw away from the +-180 wrap while it orbits
        c.angle0 = Math.PI / 2 + 0.5 + RNG.nextDouble() * (Math.PI * 2 - 2.5);

        c.sub = new SubmarineEntity(ModEntities.SUBMARINE, w);
        c.sub.refreshPositionAndAngles(c.subX, c.subY, c.subZ, c.heading, 0f);
        w.spawnEntity(c.sub);

        Vec3d h = hatch(c);
        c.missile = new MissileEntity(ModEntities.MISSILE, w);
        c.missile.refreshPositionAndAngles(h.x, c.subY - 0.25, h.z, 0f, 0f);
        w.spawnEntity(c.missile);

        Vec3d cp = orbit(c, 0);
        c.cam = new CameraEntity(ModEntities.CAMERA, w);
        c.cam.refreshPositionAndAngles(cp.x, cp.y, cp.z, 0f, 0f);
        w.spawnEntity(c.cam);
        c.lastMy = c.subY - 0.25;

        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, CUTSCENE_TICKS + 40, 4, false, false, false));
        ServerPlayNetworking.send(p, new Payloads.CutsceneControl(true, c.cam.getId(), CUTSCENE_TICKS));
        CUTSCENES.add(c);
    }

    private static void endCutscene(Cutscene c) {
        if (!c.player.isRemoved()) {
            ServerPlayNetworking.send(c.player, new Payloads.CutsceneControl(false, -1, 0));
        }
        c.sub.discard();
        c.missile.discard();
        c.cam.discard();
    }

    /** @return true when the cutscene is finished */
    private static boolean tickCutscene(Cutscene c) {
        ServerPlayerEntity p = c.player;
        ServerWorld w = c.world;
        if (p.isRemoved() || p.isDead() || p.getServerWorld() != w || c.t >= CUTSCENE_TICKS) {
            endCutscene(c);
            return true;
        }
        int t = c.t++;

        // submarine drifts forward slowly and dives after the launch
        Vec3d f = forward(c);
        c.subX += f.x * 0.03;
        c.subZ += f.z * 0.03;
        if (t > 150) c.subY -= 0.06;
        c.sub.setPosition(c.subX, c.subY, c.subZ);
        Vec3d hatch = hatch(c);

        // ---- missile
        double mx = hatch.x, mz = hatch.z, my;
        double liftBase = c.surface - 3.25;
        if (t < T_LIFT) {
            my = liftBase;
        } else if (t < T_IGNITE) {
            double k = (t - T_LIFT) / (double) (T_IGNITE - T_LIFT);
            k = k * k * (3 - 2 * k);
            my = liftBase + 8.5 * k;
        } else {
            if (t == T_IGNITE) {
                c.ignX = hatch.x;
                c.ignZ = hatch.z;
                c.ignY = liftBase + 8.5;
            }
            double dt = t - T_IGNITE;
            mx = c.ignX;
            mz = c.ignZ;
            my = c.ignY + 0.2 * dt + 0.025 * dt * dt;
        }
        c.missile.setPosition(mx, my, mz);

        // ---- effects
        if (t == 20) sound(w, c.subX, c.surface, c.subZ, "block.beacon.activate", 8f, 0.6f);
        if (t >= T_BUBBLES && t < T_IGNITE) {
            fxP(c, ParticleTypes.BUBBLE, hatch.x, c.surface - 0.5, hatch.z, 25, 3.0, 0.3, 3.0, 0.05);
            if (t >= T_LIFT) fxP(c, ParticleTypes.CLOUD, hatch.x, c.surface + 3, hatch.z, 6, 0.7, 0.3, 0.7, 0.02);
        }
        if (t == T_LIFT) sound(w, c.subX, c.surface, c.subZ, "block.iron_door.open", 8f, 0.5f);
        if (t == T_IGNITE) {
            sound(w, c.ignX, c.ignY, c.ignZ, "entity.generic.explode", 12f, 0.7f);
            sound(w, c.ignX, c.ignY, c.ignZ, "entity.firework_rocket.launch", 12f, 0.5f);
            fxP(c, ParticleTypes.EXPLOSION_EMITTER, c.ignX, c.surface + 1, c.ignZ, 2, 2, 0.5, 2, 0);
        }
        if (t >= T_IGNITE) {
            for (int k = 0; k < 4; k++) {
                double yy = c.lastMy + (my - c.lastMy) * (k / 4.0);
                fxP(c, ParticleTypes.FLAME, mx, yy, mz, 8, 0.25, 0.25, 0.25, 0.02);
                fxP(c, ParticleTypes.LARGE_SMOKE, mx, yy, mz, 5, 0.5, 0.3, 0.5, 0.01);
                fxP(c, ParticleTypes.CAMPFIRE_COSY_SMOKE, mx, yy, mz, 2, 0.3, 0.3, 0.3, 0.003);
            }
            if (t < T_IGNITE + 50) {
                fxP(c, ParticleTypes.CLOUD, mx, c.surface + 1, mz, 40, 4, 1, 4, 0.1);
                fxP(c, ParticleTypes.SPLASH, mx, c.surface + 0.5, mz, 40, 5, 0.5, 5, 0.3);
            }
            if ((t - T_IGNITE) % 6 == 0) sound(w, mx, my, mz, "item.firecharge.use", 8f, 0.5f);
        }
        c.lastMy = my;

        // ---- camera
        Vec3d cp, target;
        if (t < T_IGNITE) {
            cp = orbit(c, t);
            target = new Vec3d(c.subX, c.surface + 3.5, c.subZ);
            if (t == T_IGNITE - 1) {
                c.holdX = cp.x;
                c.holdZ = cp.z;
            }
        } else {
            double dt = t - T_IGNITE;
            double camY = c.surface + 9 + (my - c.surface) * 0.5;
            cp = new Vec3d(c.holdX, camY, c.holdZ);
            if (dt < 60) {
                double s = 0.25 * (1 - dt / 60.0);
                cp = cp.add((RNG.nextDouble() - 0.5) * s, (RNG.nextDouble() - 0.5) * s, (RNG.nextDouble() - 0.5) * s);
            }
            target = new Vec3d(mx, my + 2.5, mz);
        }
        Vec3d d = target.subtract(cp);
        double hd = Math.sqrt(d.x * d.x + d.z * d.z);
        c.cam.setPosition(cp.x, cp.y, cp.z);
        c.cam.setYaw((float) (MathHelper.atan2(-d.x, d.z) * 57.29577951308232));
        c.cam.setPitch((float) (-MathHelper.atan2(d.y, hd) * 57.29577951308232));
        return false;
    }

    // ------------------------------------------------------------------ flight / re-entry

    private static void setForced(Strike s, boolean forced) {
        if (s.forced == forced) return;
        s.forced = forced;
        int range = (OUTER_RADIUS >> 4) + 1;
        ChunkPos cp = new ChunkPos(new BlockPos(s.bx, 64, s.bz));
        for (int dx = -range; dx <= range; dx++) {
            for (int dz = -range; dz <= range; dz++) {
                s.world.setChunkForced(cp.x + dx, cp.z + dz, forced);
            }
        }
    }

    /** @return true when the strike is over */
    private static boolean tickStrike(Strike s) {
        ServerWorld w = s.world;
        s.ticksLeft--;

        if (s.ticksLeft == FORCELOAD_TICKS) setForced(s, true);

        if (s.ticksLeft > 0 && s.ticksLeft % 20 == 0) {
            int sec = s.ticksLeft / 20;
            Text txt = Text.literal(String.format("\u2622 IMPACT IN %d:%02d  -  X %d  Z %d", sec / 60, sec % 60, s.bx, s.bz))
                    .formatted(sec <= 30 ? Formatting.DARK_RED : Formatting.RED, Formatting.BOLD);
            for (ServerPlayerEntity p : w.getPlayers()) p.sendMessage(txt, true);
        }

        // warhead re-entry
        if (s.ticksLeft == REENTRY_TICKS) {
            s.groundY = w.getTopY(Heightmap.Type.WORLD_SURFACE, s.bx, s.bz);
            s.missile = new MissileEntity(ModEntities.MISSILE, w);
            s.missile.setFlipped(true);
            s.missile.refreshPositionAndAngles(s.bx + 0.5, s.groundY + 480, s.bz + 0.5, 0f, 0f);
            w.spawnEntity(s.missile);
            sound(w, s.bx, s.groundY + 100, s.bz, "entity.firework_rocket.launch", 100f, 0.4f);
        }
        if (s.missile != null && s.ticksLeft > 0) {
            double ratio = s.ticksLeft / (double) REENTRY_TICKS;
            double y = s.groundY + 480 * Math.pow(ratio, 1.5);
            double prev = s.missile.getY();
            s.missile.setPosition(s.bx + 0.5, y, s.bz + 0.5);
            for (int k = 0; k < 3; k++) {
                double yy = y + (prev - y) * (k / 3.0) + 4;
                fx(w, ParticleTypes.FLAME, s.bx + 0.5, yy, s.bz + 0.5, 6, 0.4, 0.4, 0.4, 0.02);
                fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, s.bx + 0.5, yy + 3, s.bz + 0.5, 2, 0.4, 0.4, 0.4, 0.003);
            }
        }

        if (s.ticksLeft <= 0) {
            if (s.missile != null) s.missile.discard();
            detonate(s);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ detonation

    private static void detonate(Strike s) {
        ServerWorld w = s.world;
        setForced(s, true);
        int ground = w.getTopY(Heightmap.Type.WORLD_SURFACE, s.bx, s.bz);
        Blast b = new Blast(s, ground);
        BLASTS.add(b);

        double x = s.bx + 0.5, z = s.bz + 0.5;
        Text msg = Text.literal("\u2622 DETONATION at X " + s.bx + "  Z " + s.bz).formatted(Formatting.DARK_RED, Formatting.BOLD);
        for (ServerPlayerEntity p : w.getPlayers()) p.sendMessage(msg, false);

        sound(w, x, ground, z, "entity.generic.explode", 400f, 0.5f);
        sound(w, x, ground, z, "entity.lightning_bolt.thunder", 400f, 0.4f);
        sound(w, x, ground, z, "entity.dragon_fireball.explode", 400f, 0.4f);
        fx(w, ParticleTypes.FLASH, x, ground + 20, z, 6, 12, 12, 12, 0);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, x, ground + 5, z, 10, 14, 6, 14, 0);

        // blindness flash
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.squaredDistanceTo(x, p.getY(), z) < 260 * 260) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0, false, false));
            }
        }

        // damage
        DamageSource src = w.getDamageSources().explosion(null, null);
        Box box = new Box(s.bx - OUTER_RADIUS, w.getBottomY(), s.bz - OUTER_RADIUS,
                s.bx + OUTER_RADIUS, w.getBottomY() + w.getHeight(), s.bz + OUTER_RADIUS);
        double lethal = BLAST_RADIUS * 1.15;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box, e -> true)) {
            double dist = Math.hypot(e.getX() - x, e.getZ() - z);
            if (dist <= lethal) {
                e.damage(src, 100000f);
            } else if (dist <= OUTER_RADIUS) {
                float dmg = (float) (60 * (1 - (dist - lethal) / (OUTER_RADIUS - lethal)));
                e.damage(src, dmg);
                e.setOnFireFor(8);
            }
        }
    }

    private static boolean isGround(BlockState st) {
        return st.isIn(BlockTags.DIRT) || st.isIn(BlockTags.BASE_STONE_OVERWORLD) || st.isIn(BlockTags.SAND)
                || st.isIn(BlockTags.TERRACOTTA) || st.isOf(Blocks.GRAVEL);
    }

    private static void carve(Blast b, int[] c) {
        ServerWorld w = b.w;
        int x = b.cx + c[0], z = b.cz + c[1];
        double d = Math.sqrt(c[2]);
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int minY = w.getBottomY() + 1;
        int maxY = w.getBottomY() + w.getHeight() - 1;
        BlockState air = Blocks.AIR.getDefaultState();

        if (d <= BLAST_RADIUS) {
            double cy = b.groundY + BLAST_RADIUS * 0.45;
            double half = Math.sqrt(BLAST_RADIUS * (double) BLAST_RADIUS - d * d);
            int yTop = (int) Math.min(cy + half, maxY);
            int yBot = (int) Math.max(cy - half, minY);
            for (int y = yTop; y >= yBot; y--) {
                pos.set(x, y, z);
                BlockState st = w.getBlockState(pos);
                if (st.isAir() || st.isOf(Blocks.BEDROCK)) continue;
                w.setBlockState(pos, air, BLOCK_FLAGS);
            }
        } else {
            double inner = BLAST_RADIUS * 1.5;
            if (d > inner && RNG.nextDouble() < (d - inner) / (OUTER_RADIUS - inner)) return;
            int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
            int stop = Math.max(minY, top - 90);
            for (int y = top - 1; y >= stop; y--) {
                pos.set(x, y, z);
                BlockState st = w.getBlockState(pos);
                if (st.isAir()) continue;
                if (!st.getFluidState().isEmpty()) break;
                if (isGround(st)) {
                    if (RNG.nextFloat() < 0.85f) {
                        w.setBlockState(pos, (RNG.nextFloat() < 0.25f ? Blocks.GRAVEL : Blocks.COARSE_DIRT).getDefaultState(), BLOCK_FLAGS);
                    }
                    break;
                }
                w.setBlockState(pos, air, BLOCK_FLAGS);
            }
        }
    }

    private static void mushroom(Blast b) {
        ServerWorld w = b.w;
        int age = b.age;
        double x = b.cx + 0.5, z = b.cz + 0.5, gy = b.groundY;
        double rise = Math.min(age * 1.4, 150);

        if (age < 70) {
            double r = 4 + age * 0.45;
            fx(w, ParticleTypes.FLAME, x, gy + r * 0.6, z, 120, r * 0.7, r * 0.5, r * 0.7, 0.03);
            fx(w, ParticleTypes.LARGE_SMOKE, x, gy + r * 0.6, z, 60, r * 0.8, r * 0.5, r * 0.8, 0.02);
            double ring = age * 1.7;
            for (int i = 0; i < 28; i++) {
                double a = i * Math.PI * 2 / 28 + RNG.nextDouble() * 0.2;
                fx(w, ParticleTypes.CLOUD, x + Math.cos(a) * ring, gy + 1, z + Math.sin(a) * ring, 2, 0.5, 0.8, 0.5, 0.05);
            }
        }
        if (age < 260) {
            for (int i = 0; i < 4; i++) {
                double y = gy + RNG.nextDouble() * rise;
                double sr = 4 + 3 * (1 - (y - gy) / Math.max(rise, 1));
                fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y, z, 6, sr, 3, sr, 0.01);
                if (age < 120) fx(w, ParticleTypes.FLAME, x, y, z, 4, sr * 0.6, 3, sr * 0.6, 0.01);
            }
        }
        if (age > 15 && age < 300) {
            double capR = 10 + Math.min(age * 0.28, 30);
            double capY = gy + rise;
            fx(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, x, capY, z, 70, capR, 5, capR, 0.02);
            fx(w, ParticleTypes.LARGE_SMOKE, x, capY, z, 40, capR * 0.8, 4, capR * 0.8, 0.01);
            if (age < 140) {
                fx(w, ParticleTypes.FLAME, x, capY - 3, z, 25, capR * 0.7, 2, capR * 0.7, 0.02);
                fx(w, ParticleTypes.CLOUD, x, capY + 4, z, 20, capR * 0.9, 2, capR * 0.9, 0.02);
            }
        }
        if (age % 40 == 0 && age < 200) {
            sound(w, x, gy, z, "entity.generic.explode", 300f, 0.4f + RNG.nextFloat() * 0.2f);
        }
    }

    /** @return true when the blast is finished */
    private static boolean tickBlast(Blast b) {
        b.age++;
        long end = System.nanoTime() + 22_000_000L;
        while (b.idx < b.cols.size() && System.nanoTime() < end) {
            carve(b, b.cols.get(b.idx++));
        }
        mushroom(b);
        boolean done = b.idx >= b.cols.size() && b.age > 340;
        if (done) setForced(b.strike, false);
        return done;
    }

    private NukeManager() {}
}
