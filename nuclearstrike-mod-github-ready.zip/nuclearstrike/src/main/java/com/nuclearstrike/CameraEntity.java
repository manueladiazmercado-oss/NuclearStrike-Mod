package com.nuclearstrike;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Invisible entity the client's camera is attached to during the launch cutscene. */
public class CameraEntity extends SceneEntity {
    public CameraEntity(EntityType<?> type, World world) {
        super(type, world);
    }
}
