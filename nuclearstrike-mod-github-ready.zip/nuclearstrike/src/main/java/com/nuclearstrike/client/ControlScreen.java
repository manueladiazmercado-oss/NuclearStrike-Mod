package com.nuclearstrike.client;

import com.nuclearstrike.NuclearStrike;
import com.nuclearstrike.Payloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** The handheld terminal: target coordinates, code entry, ARM button and the big red button. */
public class ControlScreen extends Screen {
    private static final int W = 176, H = 244;

    private TextFieldWidget xField, zField, codeField;
    private ButtonWidget armButton;
    private boolean armed;
    private String message = "ENTER TARGET + CODE";
    private int messageColor = 0xFFB0B0B0;
    private int left, top;

    public ControlScreen() {
        super(Text.translatable("gui.nuclearstrike.title"));
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = (this.height - H) / 2;

        xField = new TextFieldWidget(this.textRenderer, left + 14, top + 92, 70, 16, Text.literal("X"));
        xField.setPlaceholder(Text.literal("X"));
        xField.setMaxLength(9);
        xField.setTextPredicate(s -> s.matches("-?\\d*"));

        zField = new TextFieldWidget(this.textRenderer, left + 92, top + 92, 70, 16, Text.literal("Z"));
        zField.setPlaceholder(Text.literal("Z"));
        zField.setMaxLength(9);
        zField.setTextPredicate(s -> s.matches("-?\\d*"));

        codeField = new TextFieldWidget(this.textRenderer, left + 14, top + 124, 96, 16, Text.literal("CODE"));
        codeField.setPlaceholder(Text.literal("CODE"));
        codeField.setMaxLength(12);
        codeField.setTextPredicate(s -> s.matches("\\d*"));

        armButton = ButtonWidget.builder(Text.literal(armed ? "DISARM" : "ARM"), b -> toggleArm())
                .dimensions(left + 116, top + 123, 46, 18).build();

        addDrawableChild(xField);
        addDrawableChild(zField);
        addDrawableChild(codeField);
        addDrawableChild(armButton);
        setInitialFocus(xField);
        applyLock();
    }

    private static void click(String path, float pitch) {
        SoundEvent e = Registries.SOUND_EVENT.get(Identifier.of("minecraft", path));
        if (e != null) net.minecraft.client.MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(e, pitch));
    }

    private void applyLock() {
        xField.setEditable(!armed);
        zField.setEditable(!armed);
        codeField.setEditable(!armed);
        armButton.setMessage(Text.literal(armed ? "DISARM" : "ARM"));
    }

    private Integer parse(TextFieldWidget f) {
        try {
            return Integer.parseInt(f.getText());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void say(String text, int color) {
        message = text;
        messageColor = color;
    }

    private void toggleArm() {
        if (armed) {
            armed = false;
            say("DISARMED", 0xFFFFC040);
            click("block.lever.click", 0.8f);
            applyLock();
            return;
        }
        if (parse(xField) == null || parse(zField) == null) {
            say("INVALID TARGET COORDINATES", 0xFFFF5555);
            click("entity.villager.no", 1.0f);
            return;
        }
        if (!NuclearStrike.LAUNCH_CODE.equals(codeField.getText())) {
            say("ACCESS DENIED - WRONG CODE", 0xFFFF5555);
            click("entity.villager.no", 0.8f);
            return;
        }
        armed = true;
        say("ACCESS GRANTED - WEAPON ARMED", 0xFF55FF55);
        click("entity.experience_orb.pickup", 0.7f);
        applyLock();
    }

    private void launch() {
        Integer x = parse(xField), z = parse(zField);
        if (!armed || x == null || z == null) return;
        click("block.lever.click", 0.6f);
        ClientPlayNetworking.send(new Payloads.LaunchRequest(codeField.getText(), x, z));
        this.close();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && armed) {
            double dx = mx - (left + W / 2.0), dy = my - (top + 200);
            if (dx * dx + dy * dy <= 28 * 28) {
                launch();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // drawn manually in render()
    }

    private static void disc(DrawContext ctx, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            ctx.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xB0000000);

        // body
        ctx.fill(left - 3, top - 3, left + W + 3, top + H + 3, 0xFF050607);
        ctx.fill(left, top, left + W, top + H, 0xFF2A2F36);
        ctx.fill(left + 4, top + 4, left + W - 4, top + H - 4, 0xFF1B1F24);
        ctx.fill(left + W / 2 - 22, top + 6, left + W / 2 + 22, top + 9, 0xFF3A4048);

        // title
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, left + W / 2, top + 14, 0xFFE0C040);

        // display
        ctx.fill(left + 10, top + 28, left + W - 10, top + 84, 0xFF04180C);
        ctx.fill(left + 11, top + 29, left + W - 11, top + 83, 0xFF072A14);
        boolean blink = (System.currentTimeMillis() / 450) % 2 == 0;
        String status = armed ? "STATUS: ARMED" : "STATUS: SAFE";
        int statusColor = armed ? (blink ? 0xFFFF4040 : 0xFF902020) : 0xFF40E070;
        ctx.drawTextWithShadow(this.textRenderer, status, left + 16, top + 34, statusColor);
        Integer x = parse(xField), z = parse(zField);
        String target = (x != null && z != null) ? "TARGET  X " + x + "  Z " + z : "TARGET  --- / ---";
        ctx.drawTextWithShadow(this.textRenderer, target, left + 16, top + 47, 0xFF40E070);
        ctx.drawTextWithShadow(this.textRenderer, "FLIGHT TIME 03:00", left + 16, top + 59, 0xFF40E070);
        ctx.drawTextWithShadow(this.textRenderer, message, left + 16, top + 71, messageColor);

        ctx.drawTextWithShadow(this.textRenderer, "SECURITY CODE", left + 14, top + 114, 0xFF8890A0);

        super.render(ctx, mouseX, mouseY, delta);

        // the big red button
        int cx = left + W / 2, cy = top + 200;
        double dx = mouseX - cx, dy = mouseY - cy;
        boolean hover = armed && dx * dx + dy * dy <= 28 * 28;
        if (armed) {
            int a = (int) (40 + 40 * Math.sin(System.currentTimeMillis() / 180.0));
            disc(ctx, cx, cy, 40, (a << 24) | 0xFF0000);
        }
        disc(ctx, cx, cy, 34, 0xFFE0C020);                       // hazard ring
        for (int i = 0; i < 12; i++) {
            double ang = i * Math.PI / 6;
            disc(ctx, cx + (int) (Math.cos(ang) * 31), cy + (int) (Math.sin(ang) * 31), 2, 0xFF151515);
        }
        disc(ctx, cx, cy, 28, 0xFF30343A);
        disc(ctx, cx, cy, 25, armed ? (hover ? 0xFFFF4040 : 0xFFD01818) : 0xFF4A1C1C);
        disc(ctx, cx - 6, cy - 8, 9, armed ? 0x40FFFFFF : 0x18FFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, armed ? "LAUNCH" : "LOCKED", cx, cy - 4, armed ? 0xFFFFFFFF : 0xFF808080);
    }
}
