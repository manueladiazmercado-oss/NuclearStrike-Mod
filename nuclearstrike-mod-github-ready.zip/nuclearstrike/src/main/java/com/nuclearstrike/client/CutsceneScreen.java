package com.nuclearstrike.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Transparent overlay during the cutscene: letterbox bars, captions and fades. Also blocks player input. */
public class CutsceneScreen extends Screen {
    public CutsceneScreen() {
        super(Text.empty());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // no blur / darkening
    }

    private static String caption(int t) {
        if (t < 40) return "SSBN  -  SURFACED  -  LAUNCH POSITION";
        if (t < 80) return "LAUNCH TUBE FLOODED  -  GAS GENERATOR ARMED";
        if (t < 135) return "MISSILE BREACHING THE SURFACE";
        if (t < 190) return "IGNITION  -  FIRST STAGE BURN";
        return "MISSILE EXITING THE ATMOSPHERE";
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int w = this.width, h = this.height;
        int bar = (int) (h * 0.12f);
        ctx.fill(0, 0, w, bar, 0xFF000000);
        ctx.fill(0, h - bar, w, h, 0xFF000000);

        float t = ClientCutscene.ticks + delta;
        ctx.drawTextWithShadow(this.textRenderer, "\u2622 " + caption((int) t), 14, h - bar + 9, 0xFFFF5555);
        int secs = (int) (t / 20);
        ctx.drawTextWithShadow(this.textRenderer, String.format("T+%02d", secs), w - 40, h - bar + 9, 0xFFAAAAAA);
        if (((int) (t / 10)) % 2 == 0) ctx.fill(w - 54, h - bar + 11, w - 48, h - bar + 17, 0xFFFF2222);

        // fade in / out
        float alpha = 0f;
        if (t < 12) alpha = 1f - t / 12f;
        float fadeStart = ClientCutscene.total - 22;
        if (t > fadeStart) alpha = Math.min(1f, (t - fadeStart) / 20f);
        if (alpha > 0.01f) ctx.fill(0, 0, w, h, ((int) (alpha * 255) << 24));
    }
}
