package com.nuclearstrike.client;

import com.nuclearstrike.MissileEntity;
import com.nuclearstrike.ModItems;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public class MissileRenderer extends EntityRenderer<MissileEntity> {
    private static final float SCALE = 6.0f;      // 16 model pixels = 6 blocks
    private final ItemStack stack = new ItemStack(ModItems.MISSILE_DISPLAY);

    public MissileRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(MissileEntity entity) {
        return Identifier.of("minecraft", "textures/misc/white.png");
    }

    @Override
    public boolean shouldRender(MissileEntity entity, Frustum frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public void render(MissileEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();
        matrices.translate(0, SCALE * 0.5, 0);
        if (entity.isFlipped()) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180f));
        matrices.scale(SCALE, SCALE, SCALE);
        MinecraftClient.getInstance().getItemRenderer().renderItem(stack, ModelTransformationMode.FIXED,
                0xF000F0, OverlayTexture.DEFAULT_UV, matrices, vertexConsumers, entity.getWorld(), entity.getId());
        matrices.pop();
    }
}
