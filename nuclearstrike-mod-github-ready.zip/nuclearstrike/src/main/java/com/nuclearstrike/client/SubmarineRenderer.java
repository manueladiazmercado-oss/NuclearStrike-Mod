package com.nuclearstrike.client;

import com.nuclearstrike.ModItems;
import com.nuclearstrike.SubmarineEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public class SubmarineRenderer extends EntityRenderer<SubmarineEntity> {
    private static final float SCALE = 20.0f;     // 16 model pixels = 20 blocks (hull is 20 long)
    private final ItemStack stack = new ItemStack(ModItems.SUBMARINE_DISPLAY);

    public SubmarineRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(SubmarineEntity entity) {
        return Identifier.of("minecraft", "textures/misc/white.png");
    }

    @Override
    public boolean shouldRender(SubmarineEntity entity, Frustum frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public void render(SubmarineEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        matrices.translate(0, SCALE * 0.5, 0);
        matrices.scale(SCALE, SCALE, SCALE);
        MinecraftClient.getInstance().getItemRenderer().renderItem(stack, ModelTransformationMode.FIXED,
                0xF000F0, OverlayTexture.DEFAULT_UV, matrices, vertexConsumers, entity.getWorld(), entity.getId());
        matrices.pop();
    }
}
