package com.nuclearstrike.client;

import com.nuclearstrike.ModEntities;
import com.nuclearstrike.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NuclearStrikeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.MISSILE, MissileRenderer::new);
        EntityRendererRegistry.register(ModEntities.SUBMARINE, SubmarineRenderer::new);
        EntityRendererRegistry.register(ModEntities.CAMERA, CameraRenderer::new);

        ClientPlayNetworking.registerGlobalReceiver(Payloads.OpenDevice.ID,
                (payload, context) -> context.client().execute(() -> context.client().setScreen(new ControlScreen())));

        ClientPlayNetworking.registerGlobalReceiver(Payloads.CutsceneControl.ID, (payload, context) ->
                context.client().execute(() -> {
                    if (payload.start()) ClientCutscene.start(payload.cameraId(), payload.totalTicks());
                    else ClientCutscene.stop();
                }));

        ClientTickEvents.END_CLIENT_TICK.register(ClientCutscene::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientCutscene.reset());
    }
}
