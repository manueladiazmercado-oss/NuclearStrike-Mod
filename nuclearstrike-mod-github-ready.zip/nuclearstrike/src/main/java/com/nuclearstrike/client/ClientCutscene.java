package com.nuclearstrike.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

/** Client side state of the launch cutscene: attaches the camera to the server's camera entity. */
public final class ClientCutscene {
    public static boolean active;
    public static int ticks;
    public static int total = 250;

    private static int cameraId = -1;
    private static boolean cameraSet;
    private static boolean prevHudHidden;

    public static void start(int id, int totalTicks) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!active) prevHudHidden = mc.options.hudHidden;
        active = true;
        cameraId = id;
        cameraSet = false;
        ticks = 0;
        total = totalTicks;
        mc.options.hudHidden = true;
        mc.setScreen(new CutsceneScreen());
    }

    public static void stop() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!active) return;
        active = false;
        if (mc.player != null) mc.setCameraEntity(mc.player);
        mc.options.hudHidden = prevHudHidden;
        if (mc.currentScreen instanceof CutsceneScreen) mc.setScreen(null);
    }

    public static void reset() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (active) mc.options.hudHidden = prevHudHidden;
        active = false;
    }

    public static void tick(MinecraftClient mc) {
        if (!active) return;
        if (mc.world == null || mc.player == null) {
            reset();
            return;
        }
        ticks++;
        if (!cameraSet) {
            Entity e = mc.world.getEntityById(cameraId);
            if (e != null) {
                mc.setCameraEntity(e);
                cameraSet = true;
            }
        }
        if (!(mc.currentScreen instanceof CutsceneScreen) && !mc.player.isDead()) {
            mc.setScreen(new CutsceneScreen());
        }
        if (ticks > total + 200) stop();   // safety net if the stop packet got lost
    }

    private ClientCutscene() {}
}
