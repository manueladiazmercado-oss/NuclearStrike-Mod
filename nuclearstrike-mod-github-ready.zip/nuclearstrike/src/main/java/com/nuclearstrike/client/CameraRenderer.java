package com.nuclearstrike.client;

import com.nuclearstrike.CameraEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** The camera entity is invisible. */
public class CameraRenderer extends EntityRenderer<CameraEntity> {
    public CameraRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(CameraEntity entity) {
        return Identifier.of("minecraft", "textures/misc/white.png");
    }

    @Override
    public void render(CameraEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        // nothing to draw
    }
}
